# 变更记录

## 2026-04-05

- 初始化 `DCA Tracker` 项目骨架（React 18 + Vite 结构）
- 添加 Tailwind CSS v3、Recharts、Lucide React 相关配置与依赖声明
- 创建 `src/components`、`src/hooks`、`src/utils` 目录与基础文件
- 实现 `App.jsx` 单页 Tab 切换路由，不使用 React Router
- 搭建深色金融风 UI 基础主题、字体与全局样式
- 封装 `localStorage` 读写、DCA/VA 计算与 Yahoo Finance 行情 hook
- 创建总览、本期操作、历史记录、设置四个页面组件初版
- 完整实现 `src/utils/vaCalc.js` 的 VA 定投目标值与建议买入逻辑
- 完整实现 `src/utils/dcaCalc.js` 的 DCA 每期投入与建议股数逻辑
- 重构 `src/utils/storage.js`，提供 plan/records 专用持久化方法
- 重构 `useQuote.js`，支持 Yahoo Finance 双端点、3秒超时与手动回退
- 实现 `Settings.jsx` 的完整计划创建/编辑表单与资产权重校验
- 实现 `OperationPanel.jsx` 的多资产价格录入、建议计算与记录提交流程
- 更新 `App.jsx`、`usePlan.js`、`useRecords.js` 以接入完整计划/记录流转
- 启动本地预览服务并接入新版 `Dashboard.jsx` 总览仪表盘
- 实现新版 `History.jsx`，支持标签筛选、展开详情与 CSV 导出
- 完成收尾工作：空状态直出设置页、统一金额格式、增强行情错误处理
- 新增 `vercel.json` 与 `README.md`，补齐 Vercel 部署与使用说明
- 优化 `vite.config.js`，对 React/Recharts/Lucide 进行手动分包
- 将自动行情源切换为 Twelve Data，接入 `.env` 环境变量与手动回退提示
- 细化 Twelve Data 拉取失败提示，区分缺少 ticker、超时、断网、无效 API Key、额度耗尽与错误 ticker 等原因
- 新增历史记录删除与全量回算逻辑，并在设置页加入清除所有数据入口
- 新增历史记录 inline 编辑、JSON 备份导出与导入覆盖恢复能力
- 修复历史记录编辑后未同步重算前持仓价值、建议买入金额与建议股数的问题
- 新增 VA 目标年化率自动测算、策略说明文案与总览页问号引导标签
- 调整 IBIT 参考年化为基于 BTC 十年历史回报的保守估值，并提升总览柱状图 tooltip 可读性
- 更新自动测算历史收益率表为 10 年 CAGR 基准，并补充 TSLA/IBIT 风险提示文案
- 将总览每期投入柱状图 tooltip 的 amount 改为“投入金额”，并把等待触发标签调整为“暂不执行”
- 删除暂不执行标签，统一改为“本期暂停”，并将顶部模式文案与本期操作日期选择区改为中文和更明确的交互反馈
- 删除顶部无交互的“当前模式”展示，并将本期操作日期改为点击“执行日期”或日期文本即可呼出系统日期选择
- 统一清理总览、本期操作、设置页中的残留英文 UI 文案，改为中文展示
- 将本期操作的执行日期区域合并为整块可点击交互，点击整行即可呼出系统日期选择
- 新增预算模式（固定预算 / 无限定投），支持开放式计划的设置表单、VA/DCA 计算逻辑与总览卡片切换
- 优化无限定投模式下的历史页摘要、平均成本展示，并在灵活投入时补充提示文案
- 升级为多计划存储与顶部计划切换，支持保留旧计划和按当前计划查看记录
- 修复 VA 首期建议投入按 DCA 底仓计算、实际买入默认填充建议股数，并修复 Ticker 中文输入法兼容问题